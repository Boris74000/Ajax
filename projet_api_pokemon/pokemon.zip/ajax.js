var loadIt = document.getElementById("loadIt")
loadIt.addEventListener("click", function() {
    loadPoke()
});

function loadPoke() {
    fetch('https://pokeapi.co/api/v2/pokemon')

        .then(
        function (response) {
            return response.json()

        }
    )
        .then(
            function (data) {
                for (i=0; i<=19; i++) {

                    p = document.getElementById("poke1")

                    // Div qui contient les paragraphes "Nom" et voir "Voir détail"
                    r = document.createElement("div");
                    r.setAttribute("class", "divG")

                    p.appendChild(r);

                    // Paragraphe qui contient le nom du Pokémon
                    e = document.createElement("p")
                    e.innerHTML = data.results[i].name;

                    e2 = document.createElement("p")
                    e2.innerHTML = "Voir le détail"
                    e2.addEventListener("click", function () {
                        loadDetail(data.results[i].name)
                    });

                    //e2.addEventListener("click", loadDetail.bind(null, data.results[i].name )
                    //);

                    r.appendChild(e);
                    r.appendChild(e2);
                }

            }
        )
}

function loadDetail(name) {

    fetch(`https://pokeapi.co/api/v2/pokemon/${name}/`)

        .then(
            function (response) {
                return response.json()

            }
        )
        .then(
            function(data) {
                p = document.getElementById("detail1");
                e = document.createElement("p");
                e.innerHTML = data.id;
                p.appendChild(e);


            }
        )

}



